<!-- Lib -->
<link rel="stylesheet" href="{{ asset('frontend/assets/lib/bootstrap/dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/lib/fontawesome/css/all.css') }}">

<!-- Custom Css -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/dark.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/css/responsive.css') }}">

@yield('styles')
