<?php

return [
    'edit_profile' => '编辑个人资料',
    'update_details' => '更新您的个人信息和密码',
    'general_information' => '基本信息',
    'name' => '姓名',
    'phone' => '电话',
    'employee_number' => '员工编号',
    'team' => '团队',
    'floor' => '楼层',
    'row' => '行',
    'seat_number' => '座位号',
    'nid_number' => '身份证号',
    'password' => '新密码',
    'confirm_password' => '确认密码',
    'save_all' => '全部保存',
    'profile_photo' => '个人照片',
    'documents' => '证件',
    'nid_image' => '身份证图片',
    'trade_licence' => '营业执照',
    'visiting_card' => '名片',
    'select_one' => '请选择一个',
];
