 <footer class="bg-white rounded shadow p-4 mb-4 mt-5">
     <div class="row">
         <div class="col-12 col-md-4 col-xl-6 mb-4 mb-md-0">
             <p class="mb-0 text-center text-lg-start">2025 &copy; SoftVence Delat Crafted with <span
                     class="text-danger"><i class="bi bi-heart-fill"></i></span>
                 by <a href="#">Laravel Team</a></a>
             </p>
         </div>
     </div>
 </footer>
