<!-- Sweet Alert -->
<link type="text/css" href="{{ asset('backend/vendor/sweetalert2/dist/sweetalert2.min.css') }}" rel="stylesheet">

{{-- <!-- Dropify -->
<link type="text/css" href="{{ asset('backend/vendor/dropify-master/dist/css/dropify.min.css') }}" rel="stylesheet"> --}}

<!-- Dropify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/dropify/dist/css/dropify.min.css">

<!-- Timepicker -->
<link type="text/css" href="{{ asset('backend/vendor/timepicker/jquery.timepicker.min.css') }}" rel="stylesheet">

<!-- Fontawesome 5 -->
<link type="text/css" href="{{ asset('backend/vendor/fontawesome/css/all.css') }}" rel="stylesheet">

<!-- Notyf -->
<link type="text/css" href="{{ asset('backend/vendor/notyf/notyf.min.css') }}" rel="stylesheet">

<!-- Chosen_v1 -->
<link type="text/css" href="{{ asset('backend/vendor/chosen_v1.8.7/chosen.bootstrap.min.css') }}" rel="stylesheet">
<link type="text/css" href="{{ asset('backend/vendor/DataTables/datatables.min.css') }}" rel="stylesheet">

<!-- Select2 -->
<link type="text/css" href="{{ asset('backend/vendor/select2/select2.min.css') }}" rel="stylesheet">
<link type="text/css" href="{{ asset('backend/vendor/select2/select2-bootstrap-5-theme.min.css') }}" rel="stylesheet">

<!-- Summernote CSS -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote.min.css" rel="stylesheet">


<!-- Bootstrap Icon -->
<link type="text/css" href="{{ asset('backend/vendor/bootstrap-icons/bootstrap-icons.min.css') }}" rel="stylesheet">

<!-- Volt CSS -->
<link type="text/css" href="{{ asset('backend/css/volt.css') }}" rel="stylesheet">

<!-- Custom CSS -->
<link type="text/css" href="{{ asset('backend/css/custom.css') }}" rel="stylesheet">



@yield('style')
