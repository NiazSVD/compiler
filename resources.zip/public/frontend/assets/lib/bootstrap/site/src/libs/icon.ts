export interface SvgIconProps {
  class?: string
  height: number
  width: number
}
