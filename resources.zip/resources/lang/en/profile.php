<?php

return [
    'edit_profile' => 'Edit Profile',
    'update_details' => 'Update your personal details & password',
    'general_information' => 'General Information',
    'name' => 'Name',
    'phone' => 'Phone',
    'employee_number' => 'Employee Number',
    'team' => 'Team',
    'floor' => 'Floor',
    'row' => 'Row',
    'seat_number' => 'Seat Number',
    'nid_number' => 'NID Number',
    'password' => 'New Password',
    'confirm_password' => 'Confirm Password',
    'save_all' => 'Save All',
    'profile_photo' => 'Profile Photo',
    'documents' => 'Documents',
    'nid_image' => 'NID Image',
    'trade_licence' => 'Trade Licence',
    'visiting_card' => 'Visiting Card',
    'select_one' => 'Select One',
];
