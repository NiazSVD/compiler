<?php

return [
    'edit_profile' => 'প্রোফাইল সম্পাদনা করুন',
    'update_details' => 'আপনার ব্যক্তিগত তথ্য এবং পাসওয়ার্ড আপডেট করুন',
    'general_information' => 'সাধারণ তথ্য',
    'name' => 'নাম',
    'phone' => 'ফোন',
    'employee_number' => 'কর্মচারী নম্বর',
    'team' => 'টিম',
    'floor' => 'মেঝে',
    'row' => 'সারি',
    'seat_number' => 'আসনের নম্বর',
    'nid_number' => 'এনআইডি নম্বর',
    'password' => 'নতুন পাসওয়ার্ড',
    'confirm_password' => 'পাসওয়ার্ড নিশ্চিত করুন',
    'save_all' => 'সব সংরক্ষণ করুন',
    'profile_photo' => 'প্রোফাইল ছবি',
    'documents' => 'ডকুমেন্টস',
    'nid_image' => 'এনআইডি ছবি',
    'trade_licence' => 'ট্রেড লাইসেন্স',
    'visiting_card' => 'ভিজিটিং কার্ড',
    'select_one' => 'একটি নির্বাচন করুন',
];
